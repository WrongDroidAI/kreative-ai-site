@echo off
setlocal
set "FOLDER=%~dp0"
if "%FOLDER:~-1%"=="\" set "FOLDER=%FOLDER:~0,-1%"

powershell -NoProfile -Command "Set-Clipboard -Value '%FOLDER%'"

start msedge "edge://extensions"

echo.
echo  KreativeAI Tab Panic Button - one-time install
echo  ----------------------------------------------
echo.
echo  Edge is opening edge://extensions now.
echo  The folder path is already on your clipboard:
echo.
echo    %FOLDER%
echo.
echo  In Edge:
echo    1) Toggle "Developer mode" on (bottom-left corner).
echo    2) Click "Load unpacked".
echo    3) In the folder picker's address bar, press Ctrl+V then Enter,
echo       then click "Select Folder".
echo    4) Pin the new toolbar icon (puzzle-piece menu - pin).
echo.
echo  Done. From now on, just click the icon to use it.
echo.
pause
endlocal
